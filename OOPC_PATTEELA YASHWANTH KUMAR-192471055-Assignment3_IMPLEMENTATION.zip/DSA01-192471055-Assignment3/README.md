# OOP Using C++ – Assignment 3 (CO3)

**Student:** Patteela Yashwanth Kumar  
**Register Number:** 192471055  
**Repository:** DSA01-192471055-Assignment3

## Tasks
1. Constructors and constructor overloading
2. Copy constructors, shallow copy and deep copy
3. Dynamic constructors and destructors
4. Arithmetic and stream operator overloading
5. Increment, comparison and subscript operators
6. Rules of operator overloading and Text class
7. Complex-number class for AC impedance

## Requirements
- C++ compiler supporting C++17 (g++ recommended).

## Compile and run
Open a terminal inside the required task folder. Example:

```bash
g++ -std=c++17 -Wall -Wextra constructors.cpp -o constructors
./constructors
```

Use the matching `.cpp` filename for each task. On Windows, run the generated `.exe` file instead of `./program`.

## Output evidence
The `outputs/` folder contains terminal output captured by compiling and running the source files in this package. Output can vary slightly by compiler, especially where copy elision is involved.

## GitHub upload
Create a repository named `DSA01-192471055-Assignment3`, then upload all folders and this README. Do not upload executable files unless your faculty specifically asks for them.
