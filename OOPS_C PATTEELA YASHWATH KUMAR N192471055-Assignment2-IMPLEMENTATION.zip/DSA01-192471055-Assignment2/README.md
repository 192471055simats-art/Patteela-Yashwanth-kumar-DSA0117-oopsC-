# DSA01-192471055-Assignment2

**Name:** Patteela Yashwanth Kumar  **Register number:** 192471055
**Course:** Object Oriented Programming using C++ - Assignment 2 (CO2)

## Compiler
g++ (Ubuntu 13.3.0) 13.3.0

## Compile command
```
g++ -std=c++17 -Wall -Wextra file.cpp -o file
```
Timing programs (`Q6/q6_bench.cpp`, `Q7/q7_benchmark.cpp`) are compiled twice, with `-O0` and with `-O2`.

## How to run
```
g++ -std=c++17 -Wall -Wextra Q1/q1_complete.cpp -o q1_complete
./q1_complete
```
Or compile and run everything at once: `bash run_all.sh`

Each folder has: the `.cpp` sources, `output/` (program output and compiler messages) and `screenshots/` (add your own output screenshots).

## Results
| Task | Programs | Result |
|------|----------|--------|
| Q1 | q1_three_ways, q1_predict, q1_complete | by value leaves fee 45000; by reference/pointer give 40500; predict output `1 12 13 / 1 100 / 16 13 6` |
| Q2 | q2_register, q2_dangling, q2_alternatives | returning a reference lets the caller change the array; local reference warning then segmentation fault |
| Q3 | q3_ambiguous, q3_charge, q3_alternative | original overloads give an ambiguous-call error; redesigned set resolves all six calls |
| Q4 | q4_account, q4_circular, q4_deque | only the last 10 transactions are kept |
| Q5 | q5_predict, q5_busticket, q5_function, q5_alternative | predict output `101 103 104 4`; 3 seats issued, 1 on the waiting list |
| Q6 | q6_time, q6_bench | `205 false`; timings at -O0 and -O2 |
| Q7 | q7_benchmark | circular buffer 5x to 22x faster at -O2 for K = 10 to 500, identical statements |

Note: `Q3/q3_ambiguous.cpp` is meant to fail to compile (it shows the ambiguity error).
