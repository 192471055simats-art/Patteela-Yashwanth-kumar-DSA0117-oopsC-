#!/bin/bash
# Compiles and runs every program. Usage: bash run_all.sh
# Compiler used: g++ (Ubuntu 13.3.0) 13.3.0
FLAGS="-std=c++17 -Wall -Wextra"
for dir in Q1 Q2 Q3 Q4 Q5 Q6 Q7; do
  for src in $dir/*.cpp; do
    name=$(basename $src .cpp)
    echo "=================== $src"
    case $name in
      q3_ambiguous) g++ $FLAGS $src -o /tmp/$name 2>&1 | head -12; continue ;;   # must FAIL to compile
      q6_bench|q7_benchmark)
        g++ $FLAGS -O0 $src -o /tmp/${name}_O0 && echo "--- -O0" && /tmp/${name}_O0
        g++ $FLAGS -O2 $src -o /tmp/${name}_O2 && echo "--- -O2" && /tmp/${name}_O2 ;;
      q2_dangling) g++ $FLAGS $src -o /tmp/$name && /tmp/$name; echo "exit code $? (crash expected)" ;;
      *) g++ $FLAGS $src -o /tmp/$name && /tmp/$name ;;
    esac
  done
done
