# DSA01-<RegisterNumber>-Assignment1 : Namma Metro Smart-Card Fare System

- **Name:** <your name>
- **Register number:** <your register number>
- **Compiler:** g++ (Ubuntu 13.3.0) 13.3.0 (any g++ 11 or later works)
- **Compile command (all tasks):** `g++ -std=c++17 -Wall -Wextra <file>.cpp -o <name>`

## How to run each program
| Task | Folder | Compile and run | Result |
|------|--------|-----------------|--------|
| 1 | Task01 | `g++ -std=c++17 -Wall -Wextra main.cpp -o main && ./main` | Outer peak fare 3600 paise, balance 6400, sizeof(SmartCard)=8 |
| 2 | Task02 | same | constexpr vs macro vs enum class demo |
| 3 | Task03 | same | sizes, ranges, double precision error 1.3e-06, int overflow evidence |
| 4 | Task04 | `predict.cpp`, `corrected.cpp`; `narrowing_demo.cpp` is expected to fail to compile | Output 3 3.5 / C 68 / 1 true / s >= u |
| 5 | Task05 | `predict.cpp`, `expressions.cpp` | 11 16 / 9 6 4 / 6 4 / 3 1 -3 -1 / 18 |
| 6 | Task06 | `main.cpp`, `boundary.cpp`, `array_version.cpp` | Matches the expected output |
| 7 | Task07 | `procedural.cpp`, `oop.cpp`, `public_member.cpp` | OOP keeps balance at 6400; procedural reaches -800 |
| 8 | Task08 | `./main --echo < input_valid.txt`, `./main --echo < input_invalid.txt`, `./getline_version < input_getline.txt` | Recovers from bad input |
| 9 | Task09 | `main.cpp`, `table_tests.cpp` | 23 of 23 tests pass |
| 10 | Task10 | `main.cpp` | Totals for 20k / 500k / 3M journeys, int overflow, timing |
| 11 | Task11 | `main.cpp` (run inside Task11 so fares.cfg is found) | Final design and config-file timing |
| 12 | Task12 | `impact_demo.cpp`, `main.cpp` | Old design gives free Airport fare; revised design 14 of 14 tests pass |
